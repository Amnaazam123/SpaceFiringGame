//Amna Azam
//Bsef19m009

/*My visual studio is NOT woking with system("cls")
so i am unable to clear welcome screen.*/


/*INSTRUCTIONS::
1)-You will get 10 scores when you put consecutive 5 fires on Martianship
2)-You will get 5 scores when you put consecutive 3 fires on Starship
3)-You will lose your one live when you get 3 consecutive fires from enemy spaceship
4)-when you fire, THEN the enemy spaceships also fire at you in reaction otherwise not
5)-You will be unable to use arrow keys untill all enemy spaceships put their fire
6)-Please Make sure you do not touch boundary lines while moving your rocket
7)- Remember when when you fire at spaceships,then then spaceships also fire you.
8)-the place where fires strikes the rockets, that part of rocket is removed
*/


#include<iostream>
#include<conio.h>
#include<iomanip>
#include<windows.h>
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;
using namespace std;
#define KEY_UP 72
#define KEY_DOWN 80
#define KEY_LEFT 75
#define KEY_RIGHT 77
//to print welcome rocket on screen
void welcomescreen()
{
	//setting cursor position
	CursorPosition.X = 0;
	CursorPosition.Y = 43;
	int min_stars = 2;
	int p_height = 7;
	int p_space = p_height - 1;
	int max_stars = p_height * 2 - 1;
	for (int i = 0; i < p_height; i++)
	{
		for (int t = 0; t < 2; t++)
		{
			cout << setw(75);
			for (int j = p_space; j > i; j--)
				cout << " ";
			for (int k = 0; k < min_stars; k++)
			{
				if (t == 0)
					cout << "@";
				else
					cout << "-";
			}
			cout << endl;
		}
		min_stars += 2;
	}
	int temp = 0;
	for (int i = p_height; i >= 1; i--)
	{
		for (int t = 0; t < 2; t++)
		{
			cout << setw(75);
			for (int j = p_space; j >= i; j--)
				cout << " ";
			for (int k = 0; k <= max_stars - 1; k++)
			{
				if (t == 0)
					cout << "@";
				else
					cout << "-";
			}
			cout << endl;
		}
		temp++;
		if (temp == 4)
		{
			min_stars = 7;
			for (int i = 0; i < p_height; i++)
			{
				cout << setw(71);
				cout << " ";
				for (int j = p_space; j > i; j--)
					cout << " ";
				for (int k = 0; k < min_stars; k++)
				{
					if (min_stars == 7)
						cout << "-";
					else
						cout << "@";
				}
				cout << endl;
				min_stars += 2;
			}
			break;
		}
		max_stars -= 2;
	}
	cout << endl;
	for (int j = 0; j < 4; j++)
	{
		for (int i = 0; i < 71; i++)
			cout << " ";
		for (int i = 0; i < 7; i++)
			cout << "|  ";
		cout << endl;
	}
	cout << "\n\n\n";
	cout << setw(87);
	cout << "S  T  A  R  T";
	cout << "\n\n";
	char charinput;
	cout << setw(94);
	cout << "Press 'S' to START your game";
	do {
		charinput = _getch();
	} while (charinput != 's');
	cout << "\n\n\n\n\n";
}
//this function is called while firing
void clrscreen()
{
	for (int i = 0; i < 5; i++)
		cout << "     ";
}
//fireball class
class fireBall
{
protected:
	static int score;
	static int numoflives;
	static int numoffires;
public:
	void yourscore(int, int, int);                //function for displaying scores
};
int fireBall::score = 0;
int fireBall::numoflives = 3;
int fireBall::numoffires = 0;
void fireBall::yourscore(int x, int y, int firecount)
{
	int check = 0;
	numoffires++;

	//checks for martianships
	if ((x >= 0 && x <= 13) || (x >= 41 && x <= 54) || (x >= 82 && x <= 95) || (x >= 123 && x <= 136))
	{
		if (firecount == 3)
			numoflives--;
		if (firecount == 5)
			score += 10;

	}
	//checks for starships
	if ((x >= 18 && x <= 29) || (x >= 59 && x <= 70) || (x >= 100 && x <= 111))
	{
		if (firecount == 3)
		{
			numoflives--;
			score += 5;
		}
	}

	//game terminating conditions
	if (numoflives == 0 || score == 100)
	{
		SetConsoleCursorPosition(console, CursorPosition);
		if (numoflives == 0)
		{
			cout << "SORRY, you have lost all your lives\n";
			check = 1;
		}
		if (score == 100)
			cout << "CONGRATS, you have got maximum score";
		exit(0);
	}
	CursorPosition.Y = 40;
	CursorPosition.X = 0;
	SetConsoleCursorPosition(console, CursorPosition);
	cout << "==> Your SCORE ::" << score;
	cout << "\n==> Number of FIRES, you hit :: " << numoffires;
	if (check == 0)
		cout << "\n==> Number of lives, you have :: " << numoflives;
	else
		cout << "\n==> Number of lives, you have :: 0";

}

//spaceship class
class spaceship
{
protected:
	static int score;
	int xloc;
	int yloc;
	fireBall *fs;                //for fireball-class-object array
	int size;
public:
	virtual void fire();
	virtual void move(int);
	spaceship();
	~spaceship();
	virtual void draw(int) = 0;
};
//spaceship class constructor
spaceship::spaceship()
{
	xloc = 0;
	yloc=0;
	size = 100;
	//dynamic memory for fireball object array in spaceship class 
	for (int i = 0; i < size; i++)
		fs = new fireBall[i];
}
//destructor
spaceship::~spaceship()
{
	delete[] fs;
}
void spaceship::fire()
{
	//since we cannot make instance of abstract class
	//SO it is useless to define its body 
}
void spaceship::move(int p)
{
	//since we cannot make instance of abstract class
	//SO it is useless to define its body 
}
int spaceship::score = 0;           //static var


//martianship class
class Martianship :public spaceship
{
protected:
	fireBall* mfb;         //for fireball-class-object array
	int m_size;
	//bigger,destroyed with 5 consecutive fires
public:
	void draw(int);
	void move(int);
	void fire(int,int);
	Martianship();
	~Martianship();
};
//Martianship class constructor
Martianship::Martianship()
{
	m_size = 100;
	for (int i = 0; i < size; i++)
		mfb = new fireBall[i];
}
//destructor for fireball class object array 
Martianship::~Martianship()
{
	delete[] mfb;
}
void Martianship::draw(int p)
{
	if(p==0)
		CursorPosition.X = 0;
		if (p != 0)
		CursorPosition.X += 23;
		CursorPosition.Y = 43;
		//dashes (just smoke view for spaceship)
		SetConsoleCursorPosition(console, CursorPosition);
		for (int i = 0; i < 3; i++)
		{
			if (p != 0)
			{
				CursorPosition.Y++;
				SetConsoleCursorPosition(console, CursorPosition);
			}
			for (int j = 0; j < 2; j++)
			{
				cout << "   -   ";
			}
			cout << endl;
		}

		//pyramid shape print
		//------
		// ----
		int p_height = 10;
		int max_stars = p_height * 2 - 1;
		int p_space = p_height - 1;
		for (int i = p_height; i >= 7; i--)
		{
			if (p != 0)
			{
				CursorPosition.Y++;
				SetConsoleCursorPosition(console, CursorPosition);
			}
			for (int j = p_space; j >= i; j--)
			{
				cout << " ";
			}
			for (int k = 7; k <= max_stars; k++)
			{
				cout << "&";
			}
			max_stars -= 2;
			cout << endl;
		}
		//square(7 rows,3 col)

		for (int i = 0; i < 3; i++)
		{
			if (p != 0)
			{
				CursorPosition.Y++;
				SetConsoleCursorPosition(console, CursorPosition);
			}
			cout << "   ";
			for (int j = 0; j < 7; j++)
			{
				cout << "&";
			}
			cout << endl;
		}


		//tail
		p_height = 4;
		max_stars = p_height * 2 - 1;
		p_space = p_height - 1;
		for (int i = p_height; i >= 1; i--)
		{
			if (p != 0)
			{
				CursorPosition.Y++;
				SetConsoleCursorPosition(console, CursorPosition);
			}
			cout << "   ";
			for (int j = p_space; j >= i; j--)
			{
				cout << " ";
			}
			for (int k = 1; k <= max_stars; k++)
			{
				cout << "&";
			}
			max_stars -= 2;
			cout << endl;
		}

	
}
void Martianship::move(int p)
{
	if(p==0)
	CursorPosition.X =0;
	CursorPosition.Y = 44;
	SetConsoleCursorPosition(console, CursorPosition);
	if (p != 0)
		CursorPosition.X += 23;
	//to clear dashes
	for (int i = 0; i < 3; i++)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		for (int j = 0; j < 2; j++)
		{
			cout << "       ";
		}
		cout << endl;
	}

	//pyrmid spaces to clear rocket
	//------
	// ----
	int p_height = 10;
	int max_stars = p_height * 2 - 1;
	int p_space = p_height - 1;
	for (int i = p_height; i >= 7; i--)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		for (int j = p_space; j >= i; j--)
		{
			cout << " ";
		}
		for (int k = 7; k <= max_stars; k++)
		{
			cout << " ";
		}
		max_stars -= 2;
		cout << endl;
	}
	//to clear square(7 rows,3 col)

	for (int i = 0; i < 3; i++)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		cout << "   ";
		for (int j = 0; j < 7; j++)
		{
			cout << " ";
		}
		cout << endl;
	}


	//to clear rocket tail
	p_height = 4;
	max_stars = p_height * 2 - 1;
	p_space = p_height - 1;
	for (int i = p_height; i >= 1; i--)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		cout << "   ";
		for (int j = p_space; j >= i; j--)
		{
			cout << " ";
		}
		for (int k = 1; k <= max_stars; k++)
		{
			cout << " ";
		}
		max_stars -= 2;
		cout << endl;
	}

}
void Martianship::fire(int x,int y)
{
	m_size--;                    //when martian ship fires, the size of fireball class is 1 decremented
	if (m_size >= 0)
	{
		fireBall fbobj;
		for (int i = 0; i < 20; i++)
		{
			SetConsoleCursorPosition(console, CursorPosition);
			cout << "|||";
			x--;
			SetConsoleCursorPosition(console, CursorPosition);
			y++;
			Sleep(30);
			cout << "   ";
			CursorPosition.X = x++;
			CursorPosition.Y = y;
		}
	}
	else
	cout << "Martianship has lose all fireballs";
}

//starship class
class starship :public spaceship
{
protected:
	fireBall* stfb;       //for fireball-class-object array
	int st_size;
public:
	void draw(int);
	void move(int);
	starship();
	~starship();
	void fire(int, int);
};
starship::starship()
{
	st_size = 100;
	for (int i = 0; i < st_size; i++)     //fireball object array
		stfb = new fireBall[i];
}
//deallocation for fireball object array
starship::~starship()
{
	delete[] stfb;
}
void starship::move(int p)
{
	CursorPosition.Y = 43;
	CursorPosition.X += 18;
	//to clear dashes(smoke)
	for (int i = 0; i < 2; i++)
	{

		CursorPosition.Y++;
		SetConsoleCursorPosition(console, CursorPosition);

		for (int j = 0; j < 1; j++)
		{
			cout << "      ";
		}
		cout << endl;
	}

	//to clear pyramid area
	//------
	// ----
	int p_height = 8;
	int max_stars = p_height * 2 - 1;
	int p_space = p_height - 1;
	for (int i = p_height; i > 6; i--)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		for (int j = p_space; j >= i; j--)
		{
			cout << " ";
		}
		for (int k = 5; k <= max_stars; k++)
		{
			cout << " ";
		}
		max_stars -= 2;
		cout << endl;
	}


	//to clear square part of rocket
	for (int i = 0; i < 2; i++)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		cout << "  ";
		for (int j = 0; j <= 6; j++)
		{
			cout << " ";
		}
		cout << endl;
	}


	//to clear rocket tail
	p_height = 4;
	max_stars = p_height * 2 - 1;
	p_space = p_height - 1;
	for (int i = p_height; i >= 1; i--)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		cout << "  ";
		for (int j = p_space; j >= i; j--)
		{
			cout << " ";
		}
		for (int k = 1; k <= max_stars; k++)
		{
			cout << " ";
		}
		max_stars -= 2;
		cout << endl;
	}



}

void starship::draw(int p)
{
	CursorPosition.Y = 43;
	CursorPosition.X += 18;
	//dashes(for smoke of rocket)
	for (int i = 0; i < 2; i++)
	{

		CursorPosition.Y++;
		SetConsoleCursorPosition(console, CursorPosition);

		for (int j = 0; j < 1; j++)
		{
			cout << "     -";
		}
		cout << endl;
	}

	//pyramid area for star spaceship
	//------
	// ----
	int p_height = 8;
	int max_stars = p_height * 2 - 1;
	int p_space = p_height - 1;
	for (int i = p_height; i > 6; i--)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		for (int j = p_space; j >= i; j--)
		{
			cout << " ";
		}
		for (int k = 5; k <= max_stars; k++)
		{
			cout << "#";
		}
		max_stars -= 2;
		cout << endl;
	}


	//square area of star spaceship
	for (int i = 0; i < 2; i++)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		cout << "  ";
		for (int j = 0; j <= 6; j++)
		{
			cout << "#";
		}
		cout << endl;
	}


	//tail of star spaceship
	p_height = 4;
	max_stars = p_height * 2 - 1;
	p_space = p_height - 1;
	for (int i = p_height; i >= 1; i--)
	{
		if (p != 0)
		{
			CursorPosition.Y++;
			SetConsoleCursorPosition(console, CursorPosition);
		}
		cout << "  ";
		for (int j = p_space; j >= i; j--)
		{
			cout << " ";
		}
		for (int k = 1; k <= max_stars; k++)
		{
			cout << "#";
		}
		max_stars -= 2;
		cout << endl;
	}




}
void starship::fire(int x,int y)
{
	st_size--;     //when starship fires, the the size of fireball is one decremented
	if (st_size >= 0)
	{
		for (int i = 0; i < 20; i++)
		{
			SetConsoleCursorPosition(console, CursorPosition);
			cout << "|||";
			x--;
			SetConsoleCursorPosition(console, CursorPosition);
			y++;
			Sleep(30);
			cout << "      ";
			CursorPosition.X = x++;
			CursorPosition.Y = y;
		}
	}
	else
		cout << "Your starship has lose all fireballs";
}

//rocket class
class rocket:public spaceship,public fireBall
{
	fireBall* rfb;
	int num_of_lives;
	int xloc;
	int yloc;
	int size;
public:
	void draw(int);
	void move();
	void fire(int,int,int);
	rocket();
};
//constructor
rocket::rocket()
{
	size = 100;
	num_of_lives = 3;
	xloc = 60;
	yloc = 78;
	for (int i = 0; i < size; i++)
		rfb = new fireBall[i];

}
void rocket::draw(int)
{

	int fact = 0;
	SetConsoleCursorPosition(console, CursorPosition);
	for (int i = 0; i < 5; i++)
		cout << "^^@@";             //my rocket display
}
void rocket::move()
{
	rocket myroc;
	int firecount = 0;
	char charinput;
	int temp1=0, temp2=0;
	while (1)
	{
		charinput = _getch();          //keys and f input
		if (charinput != 'f')
			charinput = _getch();
		
		CursorPosition.X = xloc;
		CursorPosition.Y = yloc;
		{
			switch (charinput)
			{
			case KEY_UP:                     //if up key is pressed
			{
				firecount = 0;
				SetConsoleCursorPosition(console, CursorPosition);
				clrscreen();
				CursorPosition.Y--;
				SetConsoleCursorPosition(console, CursorPosition);
				xloc = CursorPosition.X;
				yloc = CursorPosition.Y;
				myroc.draw(xloc);
				break;
			}
			case KEY_DOWN:                 //if down key is pressed
			{
				firecount = 0;
				SetConsoleCursorPosition(console, CursorPosition);
				clrscreen();
				CursorPosition.Y++;
				xloc = CursorPosition.X;
				yloc = CursorPosition.Y;
				myroc.draw(xloc);
				break;
			}
			case KEY_LEFT:       //if left key is pressed
			{
				firecount = 0;
				SetConsoleCursorPosition(console, CursorPosition);
				clrscreen();
				CursorPosition.X--;
				xloc = CursorPosition.X;
				yloc = CursorPosition.Y;
				myroc.draw(xloc);
				break;
			}
			case KEY_RIGHT:           //if right key is pressed
			{
				firecount = 0;
				SetConsoleCursorPosition(console, CursorPosition);
				clrscreen();
				CursorPosition.X++;
				xloc = CursorPosition.X;
				yloc = CursorPosition.Y;
				myroc.draw(xloc);
				break;
			}
			case 'f':                //if f key is pressed
			{
				firecount++;            //to keep check for consecutive fires
				xloc = CursorPosition.X;
				yloc = CursorPosition.Y;
				myroc.fire(this->xloc,this->yloc,firecount);       //my rocket fires here
				CursorPosition.X = xloc;
				CursorPosition.Y = yloc;
				break;
			}
			default:
				exit(0);
			}

		}	
	}

}
void rocket::fire(int x,int y,int firecount)
{
	size--;       //when rocket fires, the size of fireball class is decremented
	if (size >= 0)
	{
		fireBall fb;
		fb.yourscore(x, y, firecount);
		CursorPosition.Y = y;
		CursorPosition.X = x;
		for (int i = 0; i < 25; i++)
		{
			SetConsoleCursorPosition(console, CursorPosition);
			cout << "|||";
			x--;
			SetConsoleCursorPosition(console, CursorPosition);
			y--;
			Sleep(30);
			cout << "   ";
			CursorPosition.X = x++;
			CursorPosition.Y = y;
		}
	}
	else
		cout << "Your bullets are finished.";
		Martianship mar;
		starship star;
		//martianship and starship fires calls randomly
		mar.fire(6, 57);
		star.fire(23, 53);
		star.fire(82, 53);
		mar.fire(88, 57);
		star.fire(100, 53);
		mar.fire(47, 57);
		star.fire(64, 53);
		mar.fire(129, 57);
	
	
}

int main()
{
	welcomescreen();
	//polymorism
	spaceship* s;
	spaceship* m;
	Martianship m_obj;
	starship s_obj;
	s = &s_obj;
	m = &m_obj;

	for (int z = 0; z < 4; z++)             //for 4 times movement of spaceships
	{
		for (int p = 0; p <= 6; p++)            //for 6 martian and starships to be clear
		{
			if (p % 2 == 0)
			{
				m->move(p);
			}
			else
			{
				s->move(p);
			}
			SetConsoleCursorPosition(console, CursorPosition);
		}
		CursorPosition.X = 0;
		CursorPosition.Y = 43;
		for (int p = 0; p <= 6; p++)                 //for 6 martian and starships to be drawn
		{
			if (p % 2 == 0)
			{
				m->draw(p);
				Sleep(100);
			}
			else
			{
				s->draw(p);
				Sleep(100);
			}
			SetConsoleCursorPosition(console, CursorPosition);
		}
	}
	cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
	rocket myroc;
	int fact = 0;
	CursorPosition.X = 60;
	CursorPosition.Y = 78;
	myroc.draw(fact);        //here my rocket is drawn 
	myroc.move();            //here how my rocket moves
	return 0;
}